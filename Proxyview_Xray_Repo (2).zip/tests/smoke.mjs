/* Smoke.

   Structural checks that need no browser: the page contract the artifact
   platform enforces, the methodology invariants that must not drift, and the
   copy discipline the assurance standard requires.
*/
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { built } from '../tools/build-site.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const src = fs.readFileSync(path.join(ROOT, process.env.XRAY_FILE || 'index.html'), 'utf8');
const site = built();

/* Comments explain why a thing is absent, so they must not be searched for
   the thing itself. And the copy is written as concatenated string literals,
   so the joins are closed up before any check reads the prose. */
const code = src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
const copy = src.replace(/'\s*\n?\s*\+\s*'/g, '');

let pass = 0;
const fails = [];
const check = (name, cond, detail = '') => {
  if (cond) pass++;
  else fails.push(`${name}${detail ? ' — ' + detail : ''}`);
};

/* ── the deployed document ─────────────────────────────────────── */
/* index.html is the artifact fragment. What a host serves is the output of
   tools/build-site.mjs, and these check that document rather than the source,
   because the fragment's missing head is exactly what broke the favicon. */
check('the built document has a doctype', site.startsWith('<!doctype html>'));
check('the built document declares its language', /<html lang="en">/.test(site));
check('the built document declares an encoding', /<meta charset="utf-8">/.test(site));
check('the built document scales on a phone',
  /<meta name="viewport"[^>]*width=device-width/.test(site)
  && /viewport-fit=cover/.test(site));
check('the built document carries a favicon',
  /<link rel="icon" href="data:image\/svg\+xml/.test(site));
check('the favicon needs no second request', !/href="\/favicon/.test(site));
check('the built document has an apple touch icon', /apple-touch-icon/.test(site));
check('the built document sets a theme colour', /name="theme-color"/.test(site));
check('the built document has a description', /<meta name="description"/.test(site));
check('a shared link previews properly',
  /og:title/.test(site) && /og:description/.test(site) && /twitter:card/.test(site));
check('the title sits inside the head',
  /<head>[\s\S]*<title>Proxyview Xray<\/title>[\s\S]*<\/head>/.test(site));
check('the app sits inside the body', /<body>[\s\S]*<div class="app">/.test(site));
check('the document is closed', site.trimEnd().endsWith('</html>'));

/* The builder used to splice the document together with String.replace, which
   reads $& $` $' and $1 in the replacement as instructions. One $' in the page
   swallowed the rest of the document and shipped a script that would not
   parse. This proves the built script is still valid JavaScript. */
let parses = true;
let parseErr = '';
try {
  const m = site.match(/<script>([\s\S]*)<\/script>/);
  // eslint-disable-next-line no-new-func
  new Function(m[1]);
} catch (e) { parses = false; parseErr = e.message; }
check('the built document contains valid JavaScript', parses, parseErr);
check('the built document keeps every selector intact',
  (site.match(/\$\('#/g) || []).length === (src.match(/\$\('#/g) || []).length);

/* ── page contract ─────────────────────────────────────────────── */
check('has a <title>', /<title>[^<]{2,60}<\/title>/.test(src));
check('title is a name, not a caption',
  !/<title>[^<]*[:—-]\s/.test(src), (src.match(/<title>([^<]*)<\/title>/) || [])[1]);
check('title appears in the first 8KB', src.indexOf('<title>') < 8192);
check('the fragment carries no doctype, html, head or body of its own',
  !/<!doctype|<html[\s>]|<head[\s>]|<body[\s>]/i.test(src));

const externals = [...src.matchAll(/(?:src|href)="(https?:\/\/[^"]+)"/g)].map((m) => m[1]);
const ALLOWED = ['https://fonts.googleapis.com', 'https://fonts.gstatic.com',
  'https://cdnjs.cloudflare.com', 'https://cdn.jsdelivr.net/npm/', 'https://unpkg.com'];
const bad = externals.filter((u) => !ALLOWED.some((a) => u.startsWith(a)));
check('every external resource is on the CSP allowlist', !bad.length, bad.join(', '));
check('no iframe, object or embed', !/<(iframe|object|embed)[\s>]/i.test(src));
check('no window.print', !/window\.print/.test(src));
check('no alert, confirm or prompt dialogs',
  !/\b(alert|confirm|prompt)\s*\(/.test(src.replace(/\bprompt\w/g, '')));
check('no download attribute', !/\sdownload[\s=>]/.test(src));
check('no mailto link (unreliable in an artifact)', !/mailto:/.test(code));
check('no form posts to an external action', !/<form[^>]+action=/i.test(src));
check('every form submit is intercepted',
  (src.match(/onsubmit=/g) || []).length === (src.match(/preventDefault\(\)/g) || []).length
  || /preventDefault/.test(src));
/* Every localStorage access sits inside try/catch: a private window, blocked
   site data or a thumbnail capture can make the accessor itself throw. */
const stores = [...code.matchAll(/localStorage\.\w+/g)].length;
const guarded = [...code.matchAll(/try\s*\{[^}]*localStorage/g)].length;
check('localStorage is used', stores >= 4, String(stores));
check('every localStorage access is guarded', guarded >= 4, `${guarded} guards for ${stores} uses`);
check('the workspace survives a return visit',
  /function restoreState\(\)/.test(src) && /function saveState\(\)/.test(src));
check('only the inputs are stored, never the verdict',
  /Only the inputs are stored, never the assessment/.test(src));
check('there is a way out on a shared machine', /function forgetState\(\)/.test(src)
  && /Not you\? Start over/.test(copy));
check('the deployed build is stamped on the page', /id="buildchip"/.test(src)
  && /__BUILD__/.test(src));
check('the built document carries a real build stamp',
  /build \d{4}-\d{2}-\d{2} \d{2}:\d{2}Z/.test(site) && !site.includes('__BUILD__'));

/* append() returns undefined, so chaining a property off it throws at
   runtime and no linter catches it. One of these shipped and only the
   browser suite found it, on a case that happened to have a finding. */
const chained = [...code.matchAll(/\.append\([^;]*\)\.(style|classList|textContent|id)\b/g)].map((m) => m[0]);
check('nothing chains a property off append()', !chained.length, chained.join(' | '));

/* ── responsive and accessibility ──────────────────────────────── */
check('has a phone breakpoint', /@media\s*\(max-width:\s*8\d\dpx\)/.test(src));
check('focus-visible is styled', /:focus-visible/.test(src));
check('respects reduced motion', /prefers-reduced-motion/.test(src));
check('sticky header uses the safe-area inset',
  /top:env\(safe-area-inset-top|top: ?env\(safe-area-inset-top/.test(src));
check('body has an explicit background', /body\{[^}]*background:/.test(src));
check('single-theme design sets color-scheme', /color-scheme:\s*dark/.test(src));

const labels = [...src.matchAll(/<label for="([^"]+)"/g)].map((m) => m[1]);
const inputs = [...src.matchAll(/<(?:input|select|textarea) id="([^"]+)"/g)].map((m) => m[1]);
const unlabelled = inputs.filter((id) => !labels.includes(id) && id !== 'fileinput');
check('every visible form control has a label', !unlabelled.length, unlabelled.join(', '));
check('icon-only controls carry an aria-label',
  (src.match(/aria-label=/g) || []).length
  + (src.match(/setAttribute\('aria-label'/g) || []).length >= 3);

/* ── the capture the client is asked for ───────────────────────── */
for (const [name, id, auto] of [
  ['work email', 'gmail', 'email'],
  ['phone', 'gphone', 'tel'],
  ['company name', 'gcompany', 'organization'],
]) {
  check(`gate asks for ${name}`, src.includes(`id="${id}"`));
  check(`${name} field sets autocomplete`, new RegExp(`id="${id}"[^>]*autocomplete="${auto}"`).test(src));
}
check('consumer mailboxes are rejected',
  /CONSUMER\s*=\s*\[/.test(src) && /gmail\.com/.test(src) && /outlook\.com/.test(src));
check('contact address is the real domain',
  src.includes('hello@getproxyview.com') && !src.includes('getproyview'));
check('contact address is selectable text', /user-select:all/.test(src));
check('copy falls back when the clipboard is refused',
  /clipboard\.writeText/.test(src) && /catch/.test(src) && /selectNodeContents/.test(src));

/* ── methodology invariants ────────────────────────────────────── */
const domains = (src.match(/^\s*([PTLCNXQA]):'[^']+'/gm) || []).length;
check('eight ORA domains are defined', /P:'Source & Provenance'/.test(src) && /A:'Accountability & Custody'/.test(src));
const evCodes = [...src.matchAll(/'(EV-\d\d)':/g)].map((m) => m[1]);
check('twenty evidence classes', new Set(evCodes).size === 20, String(new Set(evCodes).size));
const ctrlCodes = [...src.matchAll(/'(PV-[PTLCNXQA]\d\d)':\{/g)].map((m) => m[1]);
check('control codes are well formed and unique',
  ctrlCodes.length === new Set(ctrlCodes).size && ctrlCodes.length >= 20, String(ctrlCodes.length));
const orfCodes = [...src.matchAll(/'(ORF-[PTLCNXQA]\d\d)'/g)].map((m) => m[1]);
check('failure codes are well formed', orfCodes.length > 0 && orfCodes.every((c) => /^ORF-[PTLCNXQA]\d\d$/.test(c)));

const f2c = src.slice(src.indexOf('const F2C'), src.indexOf('const CONTRADICTION'));
const mapped = [...f2c.matchAll(/'(PV-[PTLCNXQA]\d\d)'/g)].map((m) => m[1]);
const unknown = mapped.filter((c) => !ctrlCodes.includes(c));
check('every mapped control exists in the library', !unknown.length, [...new Set(unknown)].join(', '));

check('the four claim outcomes are exactly the standard four',
  /Substantiated/.test(src) && /Supported with limitations/.test(src)
  && /Insufficiently supported/.test(src) && /Material contradiction/.test(src));
check('four materiality levels', /M1/.test(src) && /M2/.test(src) && /M3/.test(src) && /M4/.test(src));
check('Unable to determine is a first-class result', /Unable to determine/.test(src));
check('an unimplemented control never returns a pass',
  /no technical test is implemented for this control, so no result can be asserted/.test(src));

/* ── negative-conclusion discipline ────────────────────────────── */
const scriptBody = src.slice(src.indexOf('<script>'));
const strings = [...scriptBody.matchAll(/'((?:[^'\\]|\\.){4,})'/g)].map((m) => m[1]).join(' ').toLowerCase();
for (const word of ['fraud', 'fraudulent', 'fabricated', 'misconduct']) {
  check(`no client-facing copy asserts ${word}`, !strings.includes(word));
}
check('insufficient evidence is distinguished from a false claim',
  /does not establish that the underlying claim was false/.test(copy));
check('absence of evidence is distinguished from evidence of failure',
  /Absence of evidence is distinguished/.test(copy));

/* ── samples are ours; the allowance is theirs ─────────────────── */
check('two samples open with the workspace',
  /S\.cases\.push\(sample\(assess\(SAMPLES\[0\],false\)\), sample\(assess\(SAMPLES\[3\],false\)\)\)/.test(src));
check('a sample is flagged rather than disguised', /const sample = a => \{ a\.sample = true/.test(src));
check('the allowance counts the client\'s own cases only',
  /const own = \(\) => S\.cases\.filter\(a => !a\.sample\)/.test(src));
check('every allowance gate uses that count',
  !/S\.cases\.length\s*>=\s*FREE/.test(src) && /const atLimit/.test(src));
check('the rail separates the samples from their cases',
  /grouphead/.test(src) && /'SAMPLES'/.test(src) && /'YOUR CASES'/.test(src));
check('a sample carries a visible badge in the list', /chip samp/.test(src));
check('the report says a sample is not theirs',
  /It is not one of your cases and it has not used any of your/.test(copy));
check('the meter says the samples do not count',
  /The samples above are ours and do not count/.test(copy));
check('the portfolio never mixes our cases into theirs',
  /Your own cases, never mixed with ours/.test(src));
check('the sample-book runner is gone', !/runSampleBook/.test(src));

/* ── metering ──────────────────────────────────────────────────── */
check('the free allowance is five cases', /const FREE = 5/.test(src));
check('both a card and an invoice route exist',
  /Pay by card/.test(src) && /Request an invoice/.test(src));
check('no price is stated, because pricing is a conversation',
  !/\$\d/.test(copy) && !/\[YOUR PRICE\]/.test(src));
check('no card details are collected on the page',
  !/cc-number|cc-csc|card number/i.test(src));
check('the page says no card details are taken', /No card details are taken on this page/.test(copy));
check('the contact address is offered on the paywall',
  (src.match(/CONTACT/g) || []).length >= 4);

/* ── privacy and the security mark ─────────────────────────────── */
check('a privacy statement exists', /Privacy and security/.test(copy));
check('the security mark is drawn inline, not loaded',
  /const SHIELD/.test(src) && /<svg[^>]*aria-label="Security and privacy"/.test(src));
check('the statement says who holds the details', /held by Proxyview/.test(copy));
check('the statement gives a deletion route',
  /Ask us to delete anything we hold/.test(copy));
check('the statement is honest that files are transmitted',
  /transmitted to Proxyview/.test(copy));
check('the statement steers away from personal data',
  /Do not upload medical records, identity documents or payment details/.test(copy));
check('the page no longer claims nothing is sent',
  !/stay in this browser and nothing is sent/.test(copy));

/* ── the three Netlify forms ───────────────────────────────────── */
for (const name of ['xray-signup', 'xray-case', 'xray-contact']) {
  check(`${name} has a static detector form`,
    new RegExp(`<form name="${name}" data-netlify="true"`).test(src));
  check(`${name} is posted by the handler`, new RegExp(`'${name}'`).test(src));
}
check('the case form accepts a file', /enctype="multipart\/form-data"/.test(src)
  && /<input type="file" name="evidence" multiple>/.test(src));
check('every detector form has a honeypot',
  (src.match(/netlify-honeypot="bot-field"/g) || []).length === 3);
check('uploads are size-guarded before they are sent',
  /MAX_FILE/.test(src) && /MAX_TOTAL/.test(src));
check('an oversized file is reported rather than dropped silently',
  /Not attached/.test(copy) && /over 8 MB/.test(copy));

/* ── size ──────────────────────────────────────────────────────── */
const kb = Buffer.byteLength(src) / 1024;
check('page is well inside the 16MB limit', kb < 16 * 1024, `${kb.toFixed(0)} KB`);

console.log(`smoke: ${pass} passed, ${fails.length} failed  (${kb.toFixed(0)} KB)`);
fails.forEach((f) => console.log('  FAIL', f));
process.exit(fails.length ? 1 : 0);
