/* A static server for the page under test, so the suites exercise it over
   http rather than file://. The publish skeleton wraps the artifact in a
   doctype, head and body, so the server does the same: a suite that tested
   the bare fragment would not be testing what a client loads. */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { built, FAVICON_SVG } from '../tools/build-site.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

/* Serves what build-site.mjs produces, so the suites exercise the document
   that gets deployed rather than the artifact fragment it is built from. */
export function page() {
  return built();
}

export function start(port = 0) {
  const html = page();
  const server = http.createServer((req, res) => {
    const url = (req.url || '/').split('?')[0];
    if (url === '/' || url === '/index.html') {
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
      return res.end(html);
    }
    if (url === '/favicon.svg') {
      res.writeHead(200, { 'content-type': 'image/svg+xml' });
      return res.end(FAVICON_SVG);
    }
    if (url === '/favicon.ico') { res.writeHead(204); return res.end(); }
    res.writeHead(404, { 'content-type': 'text/plain' });
    res.end('not found');
  });
  return new Promise((resolve) => {
    server.listen(port, '127.0.0.1', () =>
      resolve({ server, url: `http://127.0.0.1:${server.address().port}/` }),
    );
  });
}

if (process.argv[1] && process.argv[1].endsWith('serve.mjs')) {
  const { url } = await start(Number(process.env.PORT) || 8899);
  console.log('serving', url);
}
