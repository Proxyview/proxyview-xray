/* Playwright.

   Covers what the Selenium journey does not: real file uploads through the
   file input, the evidence classification those files produce, the card
   route, phone width, reduced motion, and a console that stays silent
   through the whole journey.
*/
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { start } from './serve.mjs';

const { chromium, devices } = createRequire(import.meta.url)(
  '/home/claude/pv-app/node_modules/playwright',
);
const CHROME = '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';

let pass = 0;
const fails = [];
const check = (name, cond, detail = '') => {
  if (cond) { pass++; console.log('  ok   ' + name); }
  else { fails.push(name); console.log('  FAIL ' + name + (detail ? ' — ' + detail : '')); }
};

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'xray-files-'));
const mkfile = (name, bytes = 2048) => {
  const f = path.join(tmp, name);
  fs.writeFileSync(f, Buffer.alloc(bytes, 7));
  return f;
};

const { server, url } = await start();
const browser = await chromium.launch({ executablePath: CHROME });

const openGate = async (page) => {
  await page.goto(url, { waitUntil: 'load' });
  await page.fill('#gmail', 'kunle@meridiancap.com');
  await page.fill('#gphone', '+1 310 555 0101');
  await page.fill('#gcompany', 'Meridian Capital');
  await page.click('#gatesubmit');
  await page.waitForSelector('#worked');
};

try {
  /* ── 1. desktop journey, watching the console ───────────────── */
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 1000 } });
  const page = await ctx.newPage();
  const noise = [];
  page.on('pageerror', (e) => noise.push('pageerror: ' + e.message));
  page.on('console', (m) => {
    if (m.type() === 'error' && !/ERR_TUNNEL|net::ERR/.test(m.text())) noise.push('console: ' + m.text());
  });

  await page.goto(url, { waitUntil: 'load' });
  check('the page has the product name as its title',
    (await page.title()).trim() === 'Proxyview Xray', await page.title());

  /* the gate blocks navigation */
  await page.click('#newcase', { force: true }).catch(() => {});
  check('New case does nothing before the gate is passed',
    await page.locator('#gateform').isVisible());

  await openGate(page);
  check('the workspace opens after the gate', await page.locator('#worked').isVisible());
  check('two samples open with the workspace', (await page.locator('.caseitem').count()) === 2);
  check('the free allowance is untouched on arrival',
    (await page.locator('#used').innerText()) === '0');
  check('a sample is badged', (await page.locator('.chip.samp').count()) >= 2);

  /* ── 2. real files in, real classification out ──────────────── */
  await page.click('#newcase');
  await page.waitForSelector('#fileinput', { state: 'attached' });
  const files = [
    mkfile('site_photos_foundation.jpg'),
    mkfile('inspection_report.pdf'),
    mkfile('contractor_invoice.pdf'),
    mkfile('independent_survey.pdf'),
    mkfile('inspector_credential.json'),
  ];
  await page.setInputFiles('#fileinput', files);
  await page.waitForSelector('.filerow');
  check('every dropped file is listed', (await page.locator('.filerow').count()) === 5);

  const classes = await page.locator('.filerow .chip').allTextContents();
  check('a photograph classifies as the original observation artifact', classes.includes('EV-01'));
  check('an invoice classifies as a commercial document', classes.includes('EV-12'));
  check('an independent survey classifies as an independent observation', classes.includes('EV-10'));
  check('a credential classifies as source identity', classes.includes('EV-03'));
  check('the evidence classes are counted for the client',
    /evidence class/.test(await page.locator('#filelist').innerText()));

  const before = await page.locator('.filerow').count();
  await page.locator('.filerow button').first().click();
  check('a file can be removed before the run', (await page.locator('.filerow').count()) === before - 1);

  await page.click('#runbtn');
  await page.waitForSelector('.domains', { timeout: 20000 });
  const rep = await page.locator('.body').innerText();
  check('an incomplete upload does not come back substantiated',
    !/^Substantiated$/m.test(rep) || /Insufficiently|limitations|contradiction/.test(rep));
  check('the missing evidence is named rather than glossed over',
    /Minimum evidence not supplied/.test(rep), rep.slice(0, 120));
  check('controls that need the ingestion service say so',
    /ingestion service/.test(rep));

  /* ── 3. the trace ───────────────────────────────────────────── */
  const det = page.locator('details.finding').first();
  if (await det.count()) {
    await det.click();
    const inner = await det.innerText();
    check('the trace runs claim to evidence to test to control',
      ['CLAIM', 'EVIDENCE', 'TEST', 'RESULT', 'FAILURE', 'CONTROL', 'DOMAIN', 'MATERIALITY', 'NEXT']
        .every((k) => inner.includes(k)));
  } else {
    check('the trace runs claim to evidence to test to control', false, 'no finding produced');
  }

  /* ── 4. the card route ──────────────────────────────────────── */
  while ((await page.locator('#upgrade').isVisible()) === false) {
    await page.click('#newcase');
    await page.waitForSelector('#runbtn, #formhost', { timeout: 15000 });
    if (await page.locator('#formhost').count()) break;
    const sample = page.locator('.body .btn', { hasText: 'sample account' });
    await sample.click();
    await page.waitForSelector('.domains, #formhost', { timeout: 20000 });
  }
  check('the meter reaches the free limit', await page.locator('#upgrade').isVisible());
  await page.click('#upgrade');
  await page.waitForSelector('.plan');
  await page.locator('.plan', { hasText: 'Pay by card' }).locator('.btn').click();
  await page.waitForSelector('#cemail');
  check('the card route opens a contact form rather than a checkout',
    (await page.locator('#cno').count()) === 0 && (await page.locator('#cmsg').count()) === 1);
  check('the contact form carries the work-email hint',
    (await page.getAttribute('#cemail', 'autocomplete')) === 'email');
  await page.fill('#cmsg', 'About 400 closed draws, quarterly.');
  await page.click('#formhost .btn.primary');
  await page.waitForSelector('#formhost .pill.ok');
  const sent = await page.locator('#formhost').innerText();
  check('the contact route confirms', sent.includes('Request sent'));
  check('the confirmation keeps the completed cases open',
    sent.includes('stay open in the workspace'));

  check('the console stayed clean through the journey', !noise.length, noise.slice(0, 2).join(' | '));
  await ctx.close();

  /* ── 5. phone width ─────────────────────────────────────────── */
  const pctx = await browser.newContext({ ...devices['iPhone 13'] });
  const phone = await pctx.newPage();
  await openGate(phone);
  const overflow = await phone.evaluate(() =>
    document.documentElement.scrollWidth - document.documentElement.clientWidth);
  check('no horizontal scroll at phone width', overflow <= 1, String(overflow));
  await phone.click('#worked');
  await phone.waitForSelector('.domains');
  const o2 = await phone.evaluate(() =>
    document.documentElement.scrollWidth - document.documentElement.clientWidth);
  check('no horizontal scroll on the report at phone width', o2 <= 1, String(o2));
  check('the domain strip wraps rather than clipping',
    (await phone.locator('.dom').count()) === 8);
  const tap = await phone.locator('#newcase').boundingBox();
  check('the primary control meets the 44px touch target', tap && tap.height >= 40, String(tap?.height));
  await pctx.close();

  /* ── 6. reduced motion ──────────────────────────────────────── */
  const rctx = await browser.newContext({ reducedMotion: 'reduce', viewport: { width: 1200, height: 900 } });
  const rp = await rctx.newPage();
  await openGate(rp);
  await rp.click('#newcase');
  await rp.waitForSelector('#runbtn');
  const t0 = Date.now();
  await rp.locator('.body .btn', { hasText: 'sample account' }).click();
  await rp.waitForSelector('.domains', { timeout: 20000 });
  check('the run does not stall a reader who asked for reduced motion',
    Date.now() - t0 < 4000, String(Date.now() - t0) + 'ms');
  await rctx.close();

  /* ── 7. what actually reaches Netlify ───────────────────────── */
  {
    const nctx = await browser.newContext();
    const np = await nctx.newPage();
    const posts = [];
    await np.route('**/*', async (route) => {
      const req = route.request();
      if (req.method() === 'POST') {
        posts.push({ data: req.postData(), buf: req.postDataBuffer() });
        return route.fulfill({ status: 200, body: 'ok' });
      }
      return route.continue();
    });

    /* the gate */
    await openGate(np);
    await np.waitForTimeout(300);
    check('the gate posts the details', posts.length === 1);
    const q1 = new URLSearchParams(posts[0].data || '');
    check('the gate post names the registered form', q1.get('form-name') === 'xray-signup', String(q1.get('form-name')));
    check('the gate post carries the work email', q1.get('email') === 'kunle@meridiancap.com');
    check('the gate post carries the phone', (q1.get('phone') || '').includes('310 555 0101'));
    check('the gate post carries the company', q1.get('company') === 'Meridian Capital');
    check('the honeypot travels empty', q1.get('bot-field') === '');

    /* a case, with the files */
    await np.click('#newcase');
    await np.waitForSelector('#fileinput', { state: 'attached' });
    await np.setInputFiles('#fileinput', [
      mkfile('inspection_report.pdf'), mkfile('contractor_invoice.pdf'),
    ]);
    await np.click('#runbtn');
    await np.waitForSelector('.domains', { timeout: 20000 });
    await np.waitForTimeout(400);
    check('the case is posted once the run completes', posts.length === 2);
    const raw = (posts[1].buf || Buffer.from('')).toString('latin1');
    check('the case is sent as multipart, which is what carries a file',
      raw.includes('Content-Disposition: form-data'));
    check('the case post names the registered form', raw.includes('name="form-name"') && raw.includes('xray-case'));
    check('both uploaded files travel with it',
      raw.includes('filename="inspection_report.pdf"') && raw.includes('filename="contractor_invoice.pdf"'));
    check('the files are on the field the detector form declares',
      (raw.match(/name="evidence"/g) || []).length === 2);
    check('the email carries who sent it', raw.includes('kunle@meridiancap.com') && raw.includes('Meridian Capital'));
    check('the email carries the result, not just the files',
      raw.includes('Outcome:') && raw.includes('Materiality:') && raw.includes('Failure codes:'));
    await nctx.close();

    /* a post that is refused outright */
    const fctx = await browser.newContext();
    const fp = await fctx.newPage();
    await fp.route('**/*', (route) =>
      route.request().method() === 'POST' ? route.abort('failed') : route.continue());
    await openGate(fp);
    check('a refused post does not block the client',
      await fp.locator('#worked').isVisible());
    check('a refused post is shown rather than hidden',
      await fp.locator('#undelivered').isVisible());
    check('the failure names a way to reach us',
      (await fp.locator('#undelivered').innerText()).includes('hello@getproxyview.com'));
    await fctx.close();

    /* the exact signature of Netlify form detection being off: the page is
       served, the post 404s because no form handler exists */
    const dctx = await browser.newContext();
    const dp = await dctx.newPage();
    await dp.route('**/*', (route) =>
      route.request().method() === 'POST'
        ? route.fulfill({ status: 404, body: 'Not Found' })
        : route.continue());
    await openGate(dp);
    await dp.waitForTimeout(250);
    check('a 404 on the post is surfaced', await dp.locator('#undelivered').isVisible());
    const diag = await dp.evaluate(() => window.XRAY.diag());
    check('the diagnostic records where the post went', diag.posts[0].to === '/', String(diag.posts[0].to));
    check('the diagnostic records the status', diag.posts[0].status === 404, String(diag.posts[0].status));
    check('the diagnostic explains a 404 in terms the operator can act on',
      /form detection is off/.test(diag.posts[0].why), String(diag.posts[0].why));
    check('the console handle is available for whoever deploys it',
      typeof diag.endpoint === 'string' && diag.endpoint === 'netlify-forms');
    await dctx.close();

    /* a healthy post leaves no warning behind */
    const octx = await browser.newContext();
    const op = await octx.newPage();
    await op.route('**/*', (route) =>
      route.request().method() === 'POST' ? route.fulfill({ status: 200, body: 'ok' }) : route.continue());
    await openGate(op);
    await op.waitForTimeout(250);
    check('a delivered post shows no warning', await op.locator('#undelivered').isHidden());
    await octx.close();
  }

  /* ── 8. coming back later ───────────────────────────────────── */
  {
    const rctx2 = await browser.newContext();
    const rp2 = await rctx2.newPage();
    await rp2.route('**/*', (route) =>
      route.request().method() === 'POST' ? route.fulfill({ status: 200, body: 'ok' }) : route.continue());
    await openGate(rp2);

    /* run one real case, then leave */
    await rp2.click('#newcase');
    await rp2.waitForSelector('#runbtn', { state: 'attached' });
    await rp2.locator('.body .btn', { hasText: 'sample account' }).click();
    await rp2.waitForSelector('.domains', { timeout: 20000 });
    const before = await rp2.locator('#used').innerText();
    check('a case was run before leaving', before === '1', before);

    /* a plain reload */
    await rp2.reload({ waitUntil: 'load' });
    await rp2.waitForTimeout(300);
    check('a reload does not ask them to sign up again',
      (await rp2.locator('#gateform').count()) === 0);
    check('a reload keeps their completed case',
      (await rp2.locator('#used').innerText()) === '1');
    check('a reload keeps the samples too',
      (await rp2.locator('.caseitem').count()) === 3);
    check('a reload keeps who they are',
      (await rp2.locator('#who').innerText()).includes('Meridian Capital'));
    check('the restored report still opens',
      (await rp2.locator('.caseitem').count()) > 0);
    await rp2.locator('.caseitem').last().click();
    await rp2.waitForSelector('.domains');
    check('a restored case still produces a full report',
      (await rp2.locator('.dom').count()) === 8);

    /* a fresh tab on the same browser, which is the return visit */
    const rp3 = await rctx2.newPage();
    await rp3.goto(url, { waitUntil: 'load' });
    await rp3.waitForTimeout(300);
    check('a return visit lands in the workspace, not at the gate',
      (await rp3.locator('#gateform').count()) === 0
      && (await rp3.locator('.caseitem').count()) === 3);

    /* starting over clears it, and takes two taps */
    await rp3.click('#signout');
    check('starting over asks for confirmation',
      (await rp3.locator('#signout').innerText()).includes('Tap again'));
    await rp3.click('#signout');
    await rp3.waitForSelector('#gateform');
    check('starting over returns them to the gate', await rp3.locator('#gateform').isVisible());
    const rp4 = await rctx2.newPage();
    await rp4.goto(url, { waitUntil: 'load' });
    await rp4.waitForTimeout(250);
    check('starting over clears the stored workspace', await rp4.locator('#gateform').isVisible());
    await rctx2.close();

    /* a browser that refuses storage must still work */
    const sctx = await browser.newContext();
    const sp = await sctx.newPage();
    await sp.route('**/*', (route) =>
      route.request().method() === 'POST' ? route.fulfill({ status: 200, body: 'ok' }) : route.continue());
    await sp.addInitScript(() => {
      Object.defineProperty(window, 'localStorage', {
        get() { throw new Error('storage blocked'); },
      });
    });
    await sp.goto(url, { waitUntil: 'load' });
    await sp.fill('#gmail', 'kunle@meridiancap.com');
    await sp.fill('#gphone', '+1 310 555 0101');
    await sp.fill('#gcompany', 'Meridian Capital');
    await sp.click('#gatesubmit');
    await sp.waitForSelector('.caseitem');
    check('a browser that blocks storage still opens the workspace',
      (await sp.locator('.caseitem').count()) === 2);
    await sctx.close();
  }

  /* ── 9. the build stamp ─────────────────────────────────────── */
  {
    const bctx = await browser.newContext();
    const bp = await bctx.newPage();
    await bp.goto(url, { waitUntil: 'load' });
    const b = (await bp.locator('#buildchip').innerText()).trim();
    check('the deployed build is visible on the page', /^build \d{4}-\d{2}-\d{2} \d{2}:\d{2}Z$/.test(b), b);
    check('the placeholder was replaced', !b.includes('__BUILD__'));
    const diag = await bp.evaluate(() => window.XRAY.diag());
    check('the diagnostic reports the same build', diag.build === b, String(diag.build));
    await bctx.close();
  }

  /* ── 10. the contact route ──────────────────────────────────── */
  const cctx = await browser.newContext({ permissions: ['clipboard-write', 'clipboard-read'] });
  const cp = await cctx.newPage();
  await openGate(cp);
  check('the contact address is shown as text',
    (await cp.locator('#contactaddr').innerText()).trim() === 'hello@getproxyview.com');
  await cp.click('#copycontact');
  await cp.waitForTimeout(150);
  const label = await cp.locator('#copycontact').innerText();
  check('copying gives feedback either way', /Copied|Select/.test(label), label);
  await cctx.close();
} catch (e) {
  fails.push('threw: ' + (e && e.message ? e.message.split('\n')[0] : String(e)));
  console.log('  FAIL threw:', e && e.message ? e.message.split('\n')[0] : e);
} finally {
  await browser.close();
  server.close();
  fs.rmSync(tmp, { recursive: true, force: true });
}

console.log(`playwright: ${pass} passed, ${fails.length} failed`);
process.exit(fails.length ? 1 : 0);
