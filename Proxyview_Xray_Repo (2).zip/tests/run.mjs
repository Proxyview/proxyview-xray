/* The whole suite, in the order a failure is cheapest to diagnose:
   lint, then structure, then the two browsers. */
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const SUITES = [
  ['lint', 'lint.mjs'],
  ['smoke', 'smoke.mjs'],
  ['e2e (selenium)', 'e2e-selenium.mjs'],
  ['e2e (playwright)', 'pw-xray.mjs'],
];

const run = (file) =>
  new Promise((resolve) => {
    const p = spawn(process.execPath, [path.join(HERE, file)], { stdio: 'inherit' });
    p.on('close', (code) => resolve(code === 0));
  });

let failed = 0;
const started = Date.now();
for (const [name, file] of SUITES) {
  console.log(`\n── ${name} ${'─'.repeat(Math.max(0, 56 - name.length))}`);
  const ok = await run(file);
  if (!ok) failed++;
}
const secs = ((Date.now() - started) / 1000).toFixed(0);
console.log(`\n${SUITES.length - failed} of ${SUITES.length} suites passed in ${secs}s`);
process.exit(failed ? 1 : 0);
