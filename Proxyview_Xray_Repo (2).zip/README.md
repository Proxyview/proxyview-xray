# Proxyview Xray

`index.html` is the page source. It is an artifact fragment — it starts at
`<title>` and has no `<!doctype>`, `<html>`, `<head>` or `<body>`, because the
Claude artifact platform supplies those.

**Do not deploy `index.html` directly.** A browser will render it, but it
arrives with no character encoding, no viewport and no favicon.

## Deploying

    node tools/build-site.mjs      # writes dist/index.html and dist/favicon.svg

`netlify.toml` already tells Netlify to run that and publish `dist`, so a push
to GitHub is all that is needed.

## Testing

    node tests/run.mjs

Four suites — lint, structure, and the journey in Selenium and in Playwright.
They load the built document, so what is tested is what gets served.
