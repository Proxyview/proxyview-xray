/* Builds the deployable site from index.html.

   index.html is an artifact fragment: it starts at <title> and carries no
   doctype, <html>, <head> or <body>, because the Claude artifact platform
   supplies those. Deployed raw to a web host it still renders, since browsers
   invent the missing elements, but it arrives with no character encoding, no
   viewport and no favicon. That is why the deployed site had no icon and why
   a phone rendered it at desktop width.

   This wraps the fragment into a complete document and writes dist/index.html,
   which is the file to deploy. The test suites load the same output, so what
   is tested is what is served.

   Run:  node tools/build-site.mjs
*/
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export const SITE = {
  title: 'Proxyview Xray',
  description:
    'Retrospective portfolio assurance. Send the closed account; Xray reconstructs what the '
    + 'decision relied upon, tests the evidence across the eight ORA domains, and shows where '
    + 'assurance broke down.',
  url: 'https://xray.getproxyview.com/',
  themeColor: '#03070f',
};

/* The Proxyview mark, as an SVG favicon carried in the document rather than
   fetched. One file deploys, nothing 404s, and it stays sharp at every size.
   Modern browsers all accept an SVG favicon; the theme-color line gives the
   phone chrome the right background when the site is opened from a home
   screen. */
export const FAVICON_SVG =
  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">'
  + '<rect width="512" height="512" rx="96" fill="#03070f"/>'
  + '<polygon points="256,86 402,170 402,342 256,426 110,342 110,170" fill="none" '
  + 'stroke="#22d3ee" stroke-width="42" stroke-linejoin="miter"/>'
  + '<circle cx="256" cy="256" r="62" fill="#22d3ee"/></svg>';

const dataUri = (svg) => 'data:image/svg+xml,' + encodeURIComponent(svg);

/* head and body are composed, never spliced together with String.replace.
   A replacement string treats $& $` $' and $1 specially, and the page contains
   $('#id') selectors throughout — one $' in there silently swallowed the rest
   of the document and left a script that would not parse. */
function document_(head, body, site = SITE) {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="description" content="${site.description}">
<meta name="theme-color" content="${site.themeColor}">
<meta name="color-scheme" content="dark">
<link rel="icon" href="${dataUri(FAVICON_SVG)}" type="image/svg+xml">
<link rel="apple-touch-icon" href="${dataUri(FAVICON_SVG)}">
<link rel="canonical" href="${site.url}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Proxyview">
<meta property="og:title" content="${site.title}">
<meta property="og:description" content="${site.description}">
<meta property="og:url" content="${site.url}">
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@ProxyviewHQ">
<style>
:root{color-scheme:dark;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}
html,body{margin:0}
img{max-width:100%}
[hidden]{display:none!important}
</style>
${head}
</head>
<body>
${body}
</body>
</html>`;
}

/* The fragment opens with <title> and its own <link>/<style>, which belong in
   the head; everything from the first top-level element belongs in the body. */
/* Stamped into the page so the deployed build is visible at a glance. The
   commonest deploy question is whether a change actually went live, and a
   version in the corner answers it without a diff. Replaced with a function,
   never a string: a replacement string reads $& $` $' and $1 as
   instructions, and this page contains a $'. */
export function stamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `build ${d.getUTCFullYear()}-${p(d.getUTCMonth() + 1)}-${p(d.getUTCDate())}`
    + ` ${p(d.getUTCHours())}:${p(d.getUTCMinutes())}Z`;
}

export function build(fragment, site = SITE) {
  const marker = '\n<div class="app">';
  const at = fragment.indexOf(marker);
  if (at === -1) throw new Error('cannot find the start of the page body in index.html');
  const mark = stamp();
  const withStamp = (t) => t.split('__BUILD__').join(mark);
  return withStamp(document_(fragment.slice(0, at).trim(), fragment.slice(at).trim(), site));
}

export function read() {
  return fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
}

export function built() {
  return build(read());
}

if (process.argv[1] && process.argv[1].endsWith('build-site.mjs')) {
  const out = path.join(ROOT, 'dist');
  fs.mkdirSync(out, { recursive: true });
  const html = built();
  fs.writeFileSync(path.join(out, 'index.html'), html);
  fs.writeFileSync(path.join(out, 'favicon.svg'), FAVICON_SVG);
  console.log(`built dist/index.html  (${(Buffer.byteLength(html) / 1024).toFixed(0)} KB)`);
  console.log('built dist/favicon.svg');
}
