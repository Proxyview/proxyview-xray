/* The whole suite, in the order a failure is cheapest to diagnose:
   lint, then structure, then the two browsers. */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));

/* The Selenium driver is a platform binary and is not committed, so a fresh
   clone skips that suite with a note rather than failing on a missing file.
   Playwright covers the same journey, so a skip still leaves the page
   exercised end to end in a browser. */
const hasDriver = fs.existsSync(path.join(HERE, 'bin', 'chromedriver'));

const SUITES = [
  ['lint', 'lint.mjs', true],
  ['smoke', 'smoke.mjs', true],
  ['e2e (selenium)', 'e2e-selenium.mjs', hasDriver],
  ['e2e (playwright)', 'pw-lens.mjs', true],
];

const run = (file) =>
  new Promise((resolve) => {
    const p = spawn(process.execPath, [path.join(HERE, file)], { stdio: 'inherit' });
    p.on('close', (code) => resolve(code === 0));
  });

let failed = 0;
let skipped = 0;
const started = Date.now();
for (const [name, file, enabled] of SUITES) {
  console.log(`\n── ${name} ${'─'.repeat(Math.max(0, 56 - name.length))}`);
  if (!enabled) {
    skipped++;
    console.log('  skipped — tests/bin/chromedriver is not present.');
    console.log('  Put a chromedriver matching your Chrome there to run this suite.');
    continue;
  }
  const ok = await run(file);
  if (!ok) failed++;
}
const ran = SUITES.length - skipped;
const secs = ((Date.now() - started) / 1000).toFixed(0);
console.log(`\n${ran - failed} of ${ran} suites passed in ${secs}s`
  + (skipped ? ` (${skipped} skipped)` : ''));
process.exit(failed ? 1 : 0);
