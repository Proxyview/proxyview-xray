/* Lint.

   The page is a single HTML file, so the JavaScript lives inside <script>
   tags. ESLint cannot see it there. Each inline script is extracted to a
   temporary .js file with its offset recorded, linted, and every reported
   line mapped back to the line in index.html, so a message points at the
   real place rather than at a scratch file.
*/
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ESLint } from '/home/claude/pv-app/node_modules/eslint/lib/api.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const FILE = path.join(ROOT, process.env.XRAY_FILE || 'index.html');
const src = fs.readFileSync(FILE, 'utf8');

const blocks = [];
const re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi;
let m;
while ((m = re.exec(src)) !== null) {
  const before = src.slice(0, m.index + m[0].indexOf('>') + 1);
  blocks.push({ code: m[1], startLine: before.split('\n').length });
}

if (!blocks.length) {
  console.log('lint: no inline script found — nothing to lint');
  process.exit(1);
}

// ESLint 10 ignores files outside its base path, so the extracted blocks are
// written inside the project and removed again once linted.
const tmp = fs.mkdtempSync(path.join(ROOT, '.lint-'));
const eslint = new ESLint({
  cwd: ROOT,
  overrideConfigFile: true,
  overrideConfig: {
    languageOptions: {
      ecmaVersion: 2023,
      sourceType: 'script',
      globals: {
        window: 'readonly', document: 'readonly', navigator: 'readonly',
        getSelection: 'readonly', setTimeout: 'readonly', matchMedia: 'readonly',
        console: 'readonly', Date: 'readonly', Math: 'readonly', Set: 'readonly',
        Range: 'readonly', location: 'readonly',
        fetch: 'readonly', URLSearchParams: 'readonly', URL: 'readonly', FormData: 'readonly',
        localStorage: 'readonly', JSON: 'readonly',
      },
    },
    linterOptions: { reportUnusedDisableDirectives: true },
    rules: {
      'no-undef': 'error',
      'no-unused-vars': ['error', { args: 'none', varsIgnorePattern: '^_' }],
      'no-dupe-keys': 'error',
      'no-dupe-args': 'error',
      'no-duplicate-case': 'error',
      'no-unreachable': 'error',
      'no-fallthrough': 'error',
      'no-empty': ['error', { allowEmptyCatch: true }],
      'no-cond-assign': 'error',
      'no-constant-condition': 'error',
      'no-self-compare': 'error',
      'no-sparse-arrays': 'error',
      'valid-typeof': 'error',
      'use-isnan': 'error',
      'eqeqeq': ['warn', 'smart'],
      'no-shadow-restricted-names': 'error',
      'no-with': 'error',
      // no-implicit-globals is deliberately absent: the page is one inline
      // script and that scope is the page. Flagging it would report the
      // intended shape as a defect.
      'no-eval': 'error',
      'no-implied-eval': 'error',
      'no-new-func': 'error',
      'no-return-assign': 'error',
      'no-unsafe-negation': 'error',
      'no-unsafe-optional-chaining': 'error',
      'require-atomic-updates': 'error',
    },
  },
});

let errors = 0;
let warnings = 0;
for (const [i, b] of blocks.entries()) {
  const f = path.join(tmp, `block${i}.js`);
  fs.writeFileSync(f, b.code);
  const [res] = await eslint.lintFiles([f]);
  for (const msg of res.messages) {
    const line = b.startLine + (msg.line || 1) - 1;
    const sev = msg.severity === 2 ? 'error' : 'warning';
    if (msg.severity === 2) errors++;
    else warnings++;
    console.log(`  ${sev}  index.html:${line}:${msg.column}  ${msg.message}  (${msg.ruleId || 'parse'})`);
  }
}
fs.rmSync(tmp, { recursive: true, force: true });

const loc = blocks.reduce((n, b) => n + b.code.split('\n').length, 0);
console.log(`lint: ${blocks.length} inline script block(s), ${loc} lines — ${errors} error(s), ${warnings} warning(s)`);
process.exit(errors ? 1 : 0);
