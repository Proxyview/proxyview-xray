/* A static server for the page under test, so the suites exercise it over
   http rather than file://. The publish skeleton wraps the artifact in a
   doctype, head and body, so the server does the same: a suite that tested
   the bare fragment would not be testing what a client loads. */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { built, FAVICON_SVG } from '../tools/build-site.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

/* Serves what build-site.mjs produces, so the suites exercise the document
   that gets deployed rather than the artifact fragment it is built from. */
export function page() {
  return built();
}

/* A stand-in for the Netlify function, holding the same rule in memory so the
   suites exercise the real request path rather than a mock inside the page:
   five per organisation, taken from the work-email domain, with a plus-tag
   stripped. `quota` is exposed so a suite can seed or inspect it. */
const CONSUMER = new Set(['gmail.com', 'outlook.com', 'yahoo.com', 'hotmail.com', 'icloud.com']);
export const quota = new Map();

export function quotaKey(raw) {
  const e = String(raw || '').trim().toLowerCase();
  const at = e.lastIndexOf('@');
  if (at < 1) return null;
  let local = e.slice(0, at);
  const domain = e.slice(at + 1);
  if (!domain.includes('.')) return null;
  const plus = local.indexOf('+');
  if (plus > 0) local = local.slice(0, plus);
  return CONSUMER.has(domain) ? `person:${local}@${domain}` : `company:${domain}`;
}

function handleQuota(body) {
  const key = quotaKey(body.email);
  if (!key) return { status: 400, body: { error: 'a valid work email is required' } };
  const rec = quota.get(key) || { used: 0 };
  if (body.action === 'consume') {
    if (rec.used >= 5) return { status: 200, body: { used: rec.used, limit: 5, allowed: false } };
    rec.used += 1;
  }
  quota.set(key, rec);
  return {
    status: 200,
    body: { used: rec.used, limit: 5, allowed: rec.used < 5 || body.action === 'consume',
      scope: key.startsWith('company:') ? 'company' : 'person' },
  };
}

export function start(port = 0) {
  const html = page();
  const server = http.createServer((req, res) => {
    const url = (req.url || '/').split('?')[0];
    if (url === '/api/quota' && req.method === 'POST') {
      let raw = '';
      req.on('data', (c) => { raw += c; });
      req.on('end', () => {
        let out;
        try { out = handleQuota(JSON.parse(raw || '{}')); }
        catch { out = { status: 400, body: { error: 'expected JSON' } }; }
        res.writeHead(out.status, { 'content-type': 'application/json', 'cache-control': 'no-store' });
        res.end(JSON.stringify(out.body));
      });
      return;
    }
    if (url === '/' || url === '/index.html') {
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
      return res.end(html);
    }
    if (url === '/favicon.svg') {
      res.writeHead(200, { 'content-type': 'image/svg+xml' });
      return res.end(FAVICON_SVG);
    }
    if (url === '/favicon.ico') { res.writeHead(204); return res.end(); }
    res.writeHead(404, { 'content-type': 'text/plain' });
    res.end('not found');
  });
  return new Promise((resolve) => {
    server.listen(port, '127.0.0.1', () =>
      resolve({ server, url: `http://127.0.0.1:${server.address().port}/` }),
    );
  });
}

if (process.argv[1] && process.argv[1].endsWith('serve.mjs')) {
  const { url } = await start(Number(process.env.PORT) || 8899);
  console.log('serving', url);
}
