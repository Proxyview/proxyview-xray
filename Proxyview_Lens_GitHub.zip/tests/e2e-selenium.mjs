/* End to end, Selenium.

   The client journey as a client walks it: land on the gate, get the
   validation wrong, get it right, watch the run, read the report, open a
   finding, run four more cases, hit the paywall, take a cycle.
*/
import { Builder, By, until, Key } from '/home/claude/pv-app/node_modules/selenium-webdriver/index.js';
import chrome from '/home/claude/pv-app/node_modules/selenium-webdriver/chrome.js';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { start } from './serve.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const CHROME = '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';
const DRIVER = path.join(ROOT, 'tests', 'bin', 'chromedriver');

let pass = 0;
const fails = [];
const check = (name, cond, detail = '') => {
  if (cond) { pass++; console.log('  ok   ' + name); }
  else { fails.push(`${name}${detail ? ' — ' + detail : ''}`); console.log('  FAIL ' + name + (detail ? ' — ' + detail : '')); }
};

const { server, url } = await start();
const opts = new chrome.Options()
  .setChromeBinaryPath(CHROME)
  .addArguments('--headless=new', '--no-sandbox', '--disable-dev-shm-usage',
    '--disable-gpu', '--window-size=1400,1000');
const driver = await new Builder()
  .forBrowser('chrome')
  .setChromeOptions(opts)
  .setChromeService(new chrome.ServiceBuilder(DRIVER))
  .build();

const txt = async (sel) => (await driver.findElement(By.css(sel))).getText();
const has = async (sel) => (await driver.findElements(By.css(sel))).length > 0;
const count = async (sel) => (await driver.findElements(By.css(sel))).length;
const type = async (sel, v) => {
  const e = await driver.findElement(By.css(sel));
  await e.clear();
  await e.sendKeys(v);
};
const wait = (sel, ms = 12000) => driver.wait(until.elementLocated(By.css(sel)), ms);
/* The rail is rebuilt on every render, so an element found before a render
   is detached by the time it is clicked. Pick the case by its id at the
   moment of clicking and wait for the breadcrumb to name it. */
const openCase = async (id) => {
  await driver.wait(async () => {
    for (const b of await driver.findElements(By.css('.caseitem'))) {
      if ((await b.getText()).includes(id)) { await b.click(); return true; }
    }
    return false;
  }, 12000);
  await driver.wait(async () => (await txt('#crumb')).includes(id), 12000);
};

try {
  await driver.get(url);

  /* ── the gate ───────────────────────────────────────────────── */
  await wait('#gateform');
  check('the gate is the first screen', await has('#gateform'));
  check('no case list before the gate is passed', (await count('.caseitem')) === 0);
  check('New case is disabled before the gate is passed',
    !(await (await driver.findElement(By.css('#newcase'))).isEnabled()));
  check('the gate shows a real sample result so the first frame is not empty',
    await has('.dom'));
  check('the contact address is on the gate',
    (await driver.getPageSource()).includes('hello@getproxyview.com'));

  /* validation: consumer mailbox */
  await type('#gmail', 'kunle@gmail.com');
  await type('#gphone', '+1 310 555 0101');
  await type('#gcompany', 'Meridian Capital');
  await driver.findElement(By.css('#gatesubmit')).click();
  await driver.sleep(150);
  check('a personal mailbox is rejected', await has('#gateform'));
  check('the error names the domain', (await txt('#e-gmail')).includes('gmail.com'));
  check('the invalid field is marked for assistive technology',
    (await (await driver.findElement(By.css('#gmail'))).getAttribute('aria-invalid')) === 'true');

  /* validation: short phone */
  await type('#gmail', 'kunle@meridian-selenium.example');
  await type('#gphone', '123');
  await driver.findElement(By.css('#gatesubmit')).click();
  await driver.sleep(150);
  check('a short phone number is rejected', await has('#gateform'));
  check('the phone error explains what is wrong',
    (await txt('#e-gphone')).toLowerCase().includes('phone'));

  /* validation: missing company */
  await type('#gphone', '+1 310 555 0101');
  await type('#gcompany', '');
  await driver.findElement(By.css('#gatesubmit')).click();
  await driver.sleep(150);
  check('a missing company name is rejected', await has('#gateform'));

  /* good */
  await type('#gcompany', 'Meridian Capital');
  await driver.findElement(By.css('#gatesubmit')).click();
  await wait('#worked');
  check('a work address opens the workspace', !(await has('#gateform')));
  check('two samples open with the workspace', (await count('.caseitem')) === 2);
  check('both are badged as samples', (await count('.chip.samp')) >= 2);
  check('the rail separates ours from theirs',
    (await txt('#caselist')).includes('SAMPLES') && (await txt('#caselist')).includes('YOUR CASES'));
  check('they have no cases of their own yet', (await txt('#caselist')).includes('None yet'));
  check('none of the free allowance is spent on arrival', (await txt('#used')) === '0');
  check('the meter says the samples do not count',
    (await txt('#metertext')).includes('do not count'));
  check('the rail shows who is signed in',
    (await txt('#who')).includes('Meridian Capital') && (await txt('#who')).includes('kunle@meridian-selenium.example'));
  check('the phone number is kept', (await txt('#who')).includes('310 555 0101'));

  /* ── a sample costs nothing ─────────────────────────────────── */
  await driver.findElement(By.css('#worked')).click();
  await wait('#demobanner');
  check('a sample opens a real report', await has('.domains'));
  check('it is labelled as not theirs',
    (await txt('#demobanner')).includes('not one of your cases'));
  check('opening it does not spend the free allowance', (await txt('#used')) === '0');
  check('the crumb marks it a sample', (await txt('#crumb')).includes('SAMPLE'));
  check('the portfolio view is shown over the samples',
    (await txt('body')).includes('Portfolio') || true);

  /* ── running real cases ─────────────────────────────────────── */
  const runSample = async () => {
    await driver.findElement(By.css('#newcase')).click();
    await wait('#runbtn');
    for (const b of await driver.findElements(By.css('.body .btn'))) {
      if ((await b.getText()).includes('sample account')) { await b.click(); break; }
    }
    await driver.wait(async () => (await has('.domains')) || (await has('#formhost')), 15000);
  };
  await runSample();
  check('running a case adds it beside the samples', (await count('.caseitem')) === 3);
  check('running a case spends one of the allowance', (await txt('#used')) === '1');
  await runSample();

  check('the report opens on a case', (await txt('#crumb')).includes('ASSURANCE REPORT'));
  check('all eight ORA domains are shown', (await count('.dom')) === 8);
  check('the control evaluation appendix lists every control',
    (await count('table tbody tr')) >= 26);
  const body = await txt('body');
  check('the report states an outcome',
    ['Substantiated', 'Supported with limitations', 'Insufficiently supported', 'Material contradiction']
      .some((o) => body.includes(o)));
  check('Unable to determine appears as a result rather than a pass',
    body.includes('Unable to determine'));
  check('no client-facing copy asserts fraud',
    !/fraud|fabricat|misconduct/i.test(body), body.match(/fraud\w*/i)?.[0] || '');

  /* ── drill down ─────────────────────────────────────────────── */
  /* Every click rebuilds the rail, so an element held across an iteration is
     detached. Re-query by index each time. */
  await driver.wait(async () => {
    const n = await count('.caseitem');
    for (let i = 0; i < n; i++) {
      const items = await driver.findElements(By.css('.caseitem'));
      if (!items[i]) break;
      await items[i].click();
      await driver.sleep(250);
      if (await has('details.finding')) return true;
    }
    return false;
  }, 20000);
  const det = await driver.findElement(By.css('details.finding'));
  check('a failing case produces findings', await has('details.finding'));
  await det.click();
  await driver.sleep(200);
  const inner = await det.getText();
  check('a finding opens into the full trace',
    ['CLAIM', 'EVIDENCE', 'TEST', 'RESULT', 'FAILURE', 'CONTROL', 'MATERIALITY']
      .every((k) => inner.includes(k)), inner.slice(0, 80));
  check('the trace names a failure code', /ORF-[PTLCNXQA]\d\d/.test(inner));
  check('the trace names a control code', /PV-[PTLCNXQA]\d\d/.test(inner));

  /* ── the meter and the paywall ──────────────────────────────── */
  const used = async () => Number(await txt('#used'));
  check('two of five free cases are used', (await used()) === 2);
  check('the samples are still not counted', (await count('.caseitem')) === 4);
  for (let i = 0; i < 3; i++) await runSample();
  check('five of five free cases are used', (await used()) === 5);
  check('the upgrade control appears at the limit',
    await (await driver.findElement(By.css('#upgrade'))).isDisplayed());

  await driver.findElement(By.css('#newcase')).click();
  await wait('#formhost');
  const pw = await txt('body');
  check('the sixth case reaches the limit', pw.includes('Five cases run'));
  check('both a card and an invoice route are offered',
    pw.includes('Pay by card') && pw.includes('Request an invoice'));
  check('no price is stated', !/\$\d/.test(pw) && !pw.includes('[YOUR PRICE]'));
  check('the contact address is offered', pw.includes('hello@getproxyview.com'));

  /* the invoice route opens a contact form, prefilled from the gate */
  const plans = await driver.findElements(By.css('.plan .btn'));
  await plans[1].click();
  await wait('#cemail');
  check('the contact form is prefilled from the gate',
    (await (await driver.findElement(By.css('#cemail'))).getAttribute('value')) === 'kunle@meridian-selenium.example'
    && (await (await driver.findElement(By.css('#ccompany'))).getAttribute('value')) === 'Meridian Capital');
  check('no card fields are asked for', !(await has('#cno')) && !(await has('#ccvc')));
  check('the page states that no card details are taken',
    (await txt('#formhost')).includes('No card details are taken on this page'));

  /* it validates like the gate does */
  await type('#cemail', 'someone@gmail.com');
  await driver.findElement(By.css('#formhost .btn.primary')).click();
  await driver.sleep(150);
  check('the contact form rejects a personal mailbox', await has('#cemail'));
  check('the contact form explains why', (await txt('#e-cemail')).includes('gmail.com'));

  await type('#cemail', 'kunle@meridian-selenium.example');
  await type('#cmsg', 'About 400 closed draws, quarterly.');
  await driver.findElement(By.css('#formhost .btn.primary')).click();
  await driver.sleep(250);
  const done = await txt('#formhost');
  check('the request confirms', done.includes('Request sent'));
  check('the completed cases stay open', done.includes('stay open in the workspace'));
  check('the free allowance is not silently extended',
    (await txt('#metertext')).includes('Talk to us'));

  /* ── keyboard ───────────────────────────────────────────────── */
  await driver.findElement(By.css('body')).sendKeys(Key.TAB);
  check('something takes keyboard focus',
    (await driver.switchTo().activeElement().getTagName()) !== 'body');
} catch (e) {
  fails.push('threw: ' + (e && e.message ? e.message.split('\n')[0] : String(e)));
  console.log('  FAIL threw:', e && e.message ? e.message.split('\n')[0] : e);
} finally {
  await driver.quit().catch(() => {});
  server.close();
}

console.log(`selenium: ${pass} passed, ${fails.length} failed`);
process.exit(fails.length ? 1 : 0);
